ALIPS.PK — PROFESSIONAL WEBSITE STARTER

FILES
- index.html       Main website page
- style.css        Design and mobile responsive layout
- script.js        Product cards, category filters and WhatsApp links
- assets/logo.png  Alips logo

HOW TO PUBLISH ON GITHUB PAGES
1. Download and unzip alips_professional_website.zip.
2. Open your GitHub repository: alipssport/Alips.pk
3. Upload/replace index.html, style.css and script.js in the repository root.
4. Upload the assets folder with logo.png inside it.
5. Commit the changes.
6. Open https://alipssport.github.io/Alips.pk/ to check the site.

IMPORTANT BEFORE TAKING ORDERS
1. Open script.js and set WHATSAPP_NUMBER to your real WhatsApp number.
   Pakistan format example: 923001234567 (do not include + or spaces).
2. Replace the sample products in the products array with your real product names,
   categories, descriptions, icons and prices.
3. The included product cards are examples, not confirmation of stock or prices.

THIS VERSION
- Responsive mobile and desktop layout
- Category navigation and product filters
- WhatsApp enquiry buttons
- No online payment, customer account, cart or order database
- No hosting subscription required for GitHub Pages

HTTPS
This package does not change DNS or issue SSL certificates. Keep working on the
GitHub Pages custom-domain/HTTPS setup separately.
