/*
  ALIPS.PK WEBSITE SETTINGS
  1) Replace WHATSAPP_NUMBER with your number in international format.
     Pakistan example: 923001234567 (no +, spaces or dashes).
  2) Replace the sample products below with your real products and prices.
*/
const WHATSAPP_NUMBER = ""; // Example format: 923001234567

const products = [
  { name: "Wireless Earbuds", category: "Tech", description: "Everyday audio accessory", price: "Contact for price", icon: "♫" },
  { name: "Smart Watch", category: "Tech", description: "Smart everyday companion", price: "Contact for price", icon: "◷" },
  { name: "Signature Fragrance", category: "Perfumes", description: "A fragrance for your style", price: "Contact for price", icon: "♢" },
  { name: "Extension Board", category: "Electrical", description: "A practical home essential", price: "Contact for price", icon: "ϟ" }
];

const productGrid = document.getElementById("productGrid");
const filterButtons = document.querySelectorAll(".filter-chip");

function makeWhatsAppLink(message) {
  if (!WHATSAPP_NUMBER) return "";
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

function showWhatsAppHelp() {
  alert("Add your WhatsApp number in script.js first. Use Pakistan format without + or spaces, for example 923001234567.");
}

function renderProducts(filter = "All") {
  const shown = filter === "All" ? products : products.filter(p => p.category === filter);
  productGrid.innerHTML = shown.map((p, i) => `
    <article class="product-card">
      <div class="product-art"><span aria-hidden="true">${p.icon || "✦"}</span></div>
      <div class="product-info">
        <span class="product-category">${p.category}</span>
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <div class="product-bottom">
          <span class="product-price">${p.price}</span>
          <button class="product-order" type="button" data-product="${i}">Enquire ↗</button>
        </div>
      </div>
    </article>`).join("");

  productGrid.querySelectorAll(".product-order").forEach((button) => {
    button.addEventListener("click", () => {
      const item = shown[Number(button.dataset.product)];
      const link = makeWhatsAppLink(`Hello Alips.pk, I want to enquire about: ${item.name}. Please share details and availability.`);
      if (!link) return showWhatsAppHelp();
      window.open(link, "_blank", "noopener");
    });
  });
}

filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    filterButtons.forEach(b => b.classList.remove("active"));
    button.classList.add("active");
    renderProducts(button.dataset.filter);
  });
});

document.querySelectorAll("[data-filter-link]").forEach(link => {
  link.addEventListener("click", () => {
    const filter = link.dataset.filterLink;
    filterButtons.forEach(b => b.classList.toggle("active", b.dataset.filter === filter));
    renderProducts(filter);
  });
});

document.getElementById("contactWhatsApp").addEventListener("click", (event) => {
  event.preventDefault();
  const link = makeWhatsAppLink("Hello Alips.pk, I would like to know more about your products.");
  if (!link) return showWhatsAppHelp();
  window.open(link, "_blank", "noopener");
});

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});
navLinks.querySelectorAll("a").forEach(a => a.addEventListener("click", () => navLinks.classList.remove("open")));
document.getElementById("year").textContent = new Date().getFullYear();
renderProducts();
